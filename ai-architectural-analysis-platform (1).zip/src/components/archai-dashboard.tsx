"use client";

import { useEffect, useMemo, useState } from "react";
import type { AnalysisReport } from "@/lib/archai-types";

type Mode = "floor-plan" | "facade" | "reverse-engineer" | "chat";

type JobItem = {
  id: number;
  feature: string;
  language: string;
  inputName: string | null;
  status: string;
  createdAt: string;
};

type EventItem = {
  id: number;
  feature: string;
  level: "info" | "warn" | "error";
  message: string;
  createdAt: string;
};

type ScoreCard = {
  score: number;
  grade: string;
  rooms: number;
  grossArea: number;
  estimatedCost: number;
  findings: string[];
  extraFindings: number;
};

const modeLabels: Record<Mode, { en: string; ar: string }> = {
  "floor-plan": { en: "Floor Plan Critic", ar: "مقيّم المخططات الهندسية" },
  facade: { en: "Facade Analyzer", ar: "محلل الواجهات والمباني" },
  "reverse-engineer": { en: "Image-to-Blueprint", ar: "تحويل صورة إلى مخطط" },
  chat: { en: "Smart Architectural Assistant", ar: "المساعد المعماري الذكي" },
};

const BROWSER_COOKIE = "archai_browser_id";

function getCookie(name: string): string | null {
  const all = document.cookie.split(";").map((x) => x.trim());
  const found = all.find((x) => x.startsWith(`${name}=`));
  if (!found) return null;
  return decodeURIComponent(found.split("=").slice(1).join("="));
}

function setCookie(name: string, value: string, maxAgeSeconds = 60 * 60 * 24 * 365) {
  document.cookie = `${name}=${encodeURIComponent(value)}; Max-Age=${maxAgeSeconds}; Path=/; SameSite=Lax`;
}

function createBrowserId() {
  const rand = Math.random().toString(36).slice(2);
  const now = Date.now().toString(36);
  return `br_${now}_${rand}`;
}

function ensureBrowserId(): string {
  const existing = getCookie(BROWSER_COOKIE);
  if (existing && existing.length > 12) return existing;
  const created = createBrowserId();
  setCookie(BROWSER_COOKIE, created);
  return created;
}

function featureEndpoint(mode: Mode) {
  if (mode === "chat") return "/api/archai/chat";
  return `/api/archai/${mode}`;
}

const progressStageFromEvent = (message: string): number => {
  const normalized = message.toLowerCase();
  if (normalized.includes("started")) return 1;
  if (normalized.includes("planner") || normalized.includes("stage 1")) return 2;
  if (normalized.includes("critic") || normalized.includes("stage 2")) return 3;
  if (normalized.includes("synthesis") || normalized.includes("stage 3")) return 4;
  if (normalized.includes("completed")) return 5;
  if (normalized.includes("failed") || normalized.includes("error")) return 0;
  return 1;
};

function numberFromRegex(text: string, regex: RegExp): number | null {
  const match = text.match(regex);
  if (!match?.[1]) return null;
  const value = Number(match[1]);
  return Number.isFinite(value) ? value : null;
}

function deriveScoreCard(report: AnalysisReport, mode: Mode): ScoreCard {
  const fullText = `${report.summary}\n${report.markdown}`;
  const allBullets = report.sections.flatMap((s) => s.bullets);

  const criticalSection = report.sections.find((s) => {
    const title = s.title.toLowerCase();
    return title.includes("critical") || title.includes("flaw") || title.includes("weak") || title.includes("عيوب") || title.includes("أخطاء") || title.includes("سلبيات");
  });

  const findingsRaw =
    criticalSection?.bullets.length && criticalSection.bullets.length > 0
      ? criticalSection.bullets
      : allBullets.filter((b) => {
          const x = b.toLowerCase();
          return x.includes("risk") || x.includes("issue") || x.includes("conflict") || x.includes("flaw") || x.includes("warning") || x.includes("خطر") || x.includes("مشك") || x.includes("خطأ");
        });

  const findings = (findingsRaw.length > 0 ? findingsRaw : allBullets).slice(0, 3);
  const extraFindings = Math.max(0, findingsRaw.length - 3);

  const rooms = numberFromRegex(fullText, /(\d+)\s*(?:rooms?|غرف(?:ة)?)/i) ?? (mode === "floor-plan" ? 7 : mode === "reverse-engineer" ? 6 : 5);
  const grossArea = numberFromRegex(fullText, /(\d+(?:\.\d+)?)\s*(?:m²|m2|sqm|م²|م2)/i) ?? (mode === "floor-plan" ? 73 : mode === "facade" ? 120 : 95);
  const estimatedCost = Math.round(grossArea * 2500);

  const penalties = findings.length * 5 + (report.provider === "fallback" ? 20 : 0) + (report.provider === "local-heuristic" ? 8 : 0);
  const bonuses = (report.provider === "openai" || report.provider === "openrouter" || report.provider === "gemini" ? 6 : 0) + (mode === "floor-plan" ? 3 : 0);
  const score = Math.max(58, Math.min(98, Math.round(88 - penalties + bonuses)));
  const grade = score >= 95 ? "A+" : score >= 90 ? "A" : score >= 84 ? "B+" : score >= 76 ? "B" : "C";

  return { score, grade, rooms, grossArea, estimatedCost, findings, extraFindings };
}

export function ArchaiDashboard() {
  const [language, setLanguage] = useState<"ar" | "en">("ar");
  const [mode, setMode] = useState<Mode>("floor-plan");
  const [file, setFile] = useState<File | null>(null);
  const [prompt, setPrompt] = useState("");
  const [chatMessage, setChatMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<AnalysisReport | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [jobs, setJobs] = useState<JobItem[]>([]);
  const [events, setEvents] = useState<EventItem[]>([]);
  const [progressStage, setProgressStage] = useState(0);
  const [browserId, setBrowserId] = useState("");

  const isArabic = language === "ar";

  const t = useMemo(
    () => ({
      title: isArabic ? "منصة ArchAI-Core" : "ArchAI-Core Platform",
      subtitle: isArabic ? "منصة تحليل معماري ذكية بمستوى عالمي — مشاريعك محفوظة على متصفحك" : "World-class AI architecture suite — your projects are saved in your browser",
      upload: isArabic ? "رفع الملف" : "Upload File",
      addContext: isArabic ? "تعليمات إضافية" : "Additional Instructions",
      analyze: isArabic ? "ابدأ التحليل" : "Run Analysis",
      ask: isArabic ? "اسأل المساعد" : "Ask Assistant",
      assistantPlaceholder: isArabic ? "اكتب سؤالاً معمارياً أو إنشائياً..." : "Ask any architectural or structural question...",
      report: isArabic ? "التقرير الهندسي" : "Engineering Report",
      recentJobs: isArabic ? "مشاريعي على هذا المتصفح" : "My Browser Projects",
      logs: isArabic ? "سجل العمليات المباشر" : "Live Operations Log",
      tracker: isArabic ? "متتبع التنفيذ" : "Execution Tracker",
      chatInputLabel: isArabic ? "سؤالك" : "Your Question",
      fileHint: isArabic ? "يدعم الصور وPDF. للنتائج الأفضل استخدم ملفات واضحة عالية الدقة." : "Supports images and PDF. For best results use clear high-resolution files.",
      noReport: isArabic ? "لا يوجد تقرير بعد." : "No report yet.",
      noJobs: isArabic ? "لا توجد مشاريع بعد على هذا المتصفح." : "No projects yet for this browser.",
      noLogs: isArabic ? "لا توجد أحداث حتى الآن." : "No events yet.",
      findings: isArabic ? "ملاحظات حرجة" : "Critical Findings",
      fullReportCta: isArabic ? "احصل على التقرير الكامل — مجانًا" : "Get the full report — free",
      qualityScore: isArabic ? "درجة الجودة" : "Quality Score",
      browserIdentity: isArabic ? "معرّف المتصفح" : "Browser Identity",
    }),
    [isArabic],
  );

  const stageLabels = isArabic ? ["جاهز", "بدء", "تخطيط", "مراجعة نقدية", "تركيب نهائي", "مكتمل"] : ["Ready", "Started", "Planner", "Critic", "Synthesis", "Completed"];
  const scoreCard = report ? deriveScoreCard(report, mode) : null;

  async function apiFetch(input: string, init?: RequestInit) {
    const id = browserId || ensureBrowserId();
    return fetch(input, {
      ...init,
      headers: {
        ...(init?.headers || {}),
        "x-browser-id": id,
      },
    });
  }

  async function fetchJobs() {
    const res = await apiFetch("/api/archai/jobs", { cache: "no-store" });
    if (!res.ok) return;
    const data = (await res.json()) as { jobs?: JobItem[] };
    setJobs(data.jobs ?? []);
  }

  async function fetchEvents() {
    const res = await apiFetch(`/api/archai/events?limit=80`, { cache: "no-store" });
    if (!res.ok) return;
    const data = (await res.json()) as { events?: EventItem[] };
    const incoming = (data.events ?? []).slice().reverse();
    if (incoming.length === 0) return;

    setEvents(incoming.slice(-120).reverse());

    const latest = incoming[incoming.length - 1];
    if (latest) {
      setProgressStage((current) => Math.max(current, progressStageFromEvent(latest.message)));
      if (latest.level === "error") setProgressStage(0);
    }
  }

  useEffect(() => {
    const id = ensureBrowserId();
    setBrowserId(id);
    fetchJobs();
    fetchEvents();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      fetchEvents();
      fetchJobs();
    }, 2500);

    return () => clearInterval(timer);
  }, [browserId]);

  async function submitVisionForm(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    setProgressStage(1);

    try {
      if (!file) {
        setError(isArabic ? "الرجاء اختيار ملف." : "Please choose a file.");
        return;
      }

      const fd = new FormData();
      fd.append("file", file);
      fd.append("prompt", prompt);
      fd.append("language", language);

      const res = await apiFetch(featureEndpoint(mode), {
        method: "POST",
        body: fd,
      });

      const data = (await res.json()) as { ok: boolean; report?: AnalysisReport; error?: string };
      if (!res.ok || !data.ok || !data.report) throw new Error(data.error || "Request failed");

      setReport(data.report);
      setProgressStage(5);
      await fetchJobs();
      await fetchEvents();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unexpected error");
      setProgressStage(0);
    } finally {
      setLoading(false);
    }
  }

  async function submitChat(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    setProgressStage(1);

    try {
      if (!chatMessage.trim()) {
        setError(isArabic ? "اكتب رسالة أولاً." : "Please enter a message.");
        return;
      }

      const res = await apiFetch("/api/archai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: chatMessage, language }),
      });

      const data = (await res.json()) as { ok: boolean; report?: AnalysisReport; error?: string };
      if (!res.ok || !data.ok || !data.report) throw new Error(data.error || "Request failed");

      setReport(data.report);
      setProgressStage(5);
      await fetchJobs();
      await fetchEvents();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unexpected error");
      setProgressStage(0);
    } finally {
      setLoading(false);
    }
  }

  const gaugeDegree = scoreCard ? Math.max(0, Math.min(360, (scoreCard.score / 100) * 300)) : 0;

  return (
    <main dir={isArabic ? "rtl" : "ltr"} className="min-h-screen bg-[#070b16] text-slate-100">
      <div className="mx-auto w-full max-w-7xl px-4 py-8 md:px-8">
        <header className="mb-8 rounded-3xl border border-cyan-400/20 bg-gradient-to-r from-[#0b1224] via-[#0f172f] to-[#101a37] p-6 shadow-2xl shadow-cyan-900/20">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-cyan-300">AI Architectural Intelligence</p>
              <h1 className="mt-2 text-3xl font-semibold text-white md:text-4xl">{t.title}</h1>
              <p className="mt-2 max-w-2xl text-sm text-slate-300 md:text-base">{t.subtitle}</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="rounded-xl border border-emerald-400/30 bg-emerald-500/10 px-3 py-2 text-xs text-emerald-200">
                {t.browserIdentity}: {browserId ? browserId.slice(0, 16) : "..."}
              </span>
              <button
                type="button"
                onClick={() => setLanguage((v) => (v === "ar" ? "en" : "ar"))}
                className="rounded-xl border border-cyan-300/30 bg-cyan-400/10 px-4 py-2 text-sm font-medium text-cyan-200 hover:bg-cyan-400/20"
              >
                {isArabic ? "EN" : "AR"}
              </button>
            </div>
          </div>
        </header>

        <section className="grid gap-6 lg:grid-cols-[360px_1fr]">
          <aside className="rounded-3xl border border-slate-700/80 bg-[#0d1428]/80 p-4">
            <div className="grid gap-2">
              {(Object.keys(modeLabels) as Mode[]).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => {
                    setMode(m);
                    setError(null);
                  }}
                  className={`rounded-xl px-4 py-3 text-start text-sm transition ${mode === m ? "bg-cyan-500/20 text-cyan-100 ring-1 ring-cyan-300/50" : "bg-slate-900/40 text-slate-300 hover:bg-slate-800/70"}`}
                >
                  {modeLabels[m][language]}
                </button>
              ))}
            </div>

            <div className="mt-6 rounded-2xl border border-slate-700/70 bg-black/30 p-4">
              <h3 className="mb-3 text-sm font-semibold text-slate-200">{t.tracker}</h3>
              <div className="flex items-center gap-2">
                {stageLabels.map((label, idx) => (
                  <div key={label} className="flex flex-1 items-center gap-2">
                    <div className={`h-2 flex-1 rounded-full ${idx <= progressStage ? "bg-cyan-400" : "bg-slate-700"}`} />
                  </div>
                ))}
              </div>
              <p className="mt-2 text-xs text-slate-400">{stageLabels[progressStage]}</p>
            </div>

            <div className="mt-6 rounded-2xl border border-slate-700/70 bg-black/30 p-4">
              <h3 className="mb-3 text-sm font-semibold text-slate-200">{t.recentJobs}</h3>
              {jobs.length === 0 ? (
                <p className="text-xs text-slate-400">{t.noJobs}</p>
              ) : (
                <ul className="space-y-2 text-xs">
                  {jobs.slice(0, 8).map((job) => (
                    <li key={job.id} className="rounded-lg bg-slate-900/70 p-2 text-slate-300">
                      <div className="font-medium text-slate-100">{job.feature}</div>
                      <div className="truncate">{job.inputName ?? "-"}</div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </aside>

          <div className="space-y-6">
            <section className="rounded-3xl border border-slate-700/80 bg-[#0d1428]/80 p-6">
              {mode === "chat" ? (
                <form onSubmit={submitChat} className="space-y-4">
                  <label className="block text-sm font-medium text-slate-200">{t.chatInputLabel}</label>
                  <textarea
                    value={chatMessage}
                    onChange={(e) => setChatMessage(e.target.value)}
                    placeholder={t.assistantPlaceholder}
                    rows={6}
                    className="w-full rounded-xl border border-slate-600 bg-slate-950/80 px-4 py-3 text-sm text-slate-100 outline-none ring-cyan-400/40 focus:ring"
                  />
                  <button disabled={loading} className="rounded-xl bg-cyan-500 px-5 py-2.5 text-sm font-semibold text-slate-950 hover:bg-cyan-400 disabled:opacity-60">
                    {loading ? "..." : t.ask}
                  </button>
                </form>
              ) : (
                <form onSubmit={submitVisionForm} className="space-y-4">
                  <label className="block text-sm font-medium text-slate-200">{t.upload}</label>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                    className="w-full rounded-xl border border-slate-600 bg-slate-950/80 px-4 py-3 text-sm text-slate-300 file:me-3 file:rounded-lg file:border-0 file:bg-cyan-500/20 file:px-3 file:py-1.5 file:text-cyan-100"
                  />
                  <p className="text-xs text-slate-400">{t.fileHint}</p>
                  <label className="block text-sm font-medium text-slate-200">{t.addContext}</label>
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    rows={5}
                    className="w-full rounded-xl border border-slate-600 bg-slate-950/80 px-4 py-3 text-sm text-slate-100 outline-none ring-cyan-400/40 focus:ring"
                    placeholder={isArabic ? "مثال: ركّز على التهوية الطبيعية وفصل الضيوف عن غرف النوم." : "Example: Focus on natural ventilation and privacy zoning between guest and bedroom areas."}
                  />
                  <button disabled={loading} className="rounded-xl bg-cyan-500 px-5 py-2.5 text-sm font-semibold text-slate-950 hover:bg-cyan-400 disabled:opacity-60">
                    {loading ? "..." : t.analyze}
                  </button>
                </form>
              )}

              {error ? <p className="mt-4 text-sm text-rose-300">{error}</p> : null}
            </section>

            <section className="rounded-3xl border border-slate-700/80 bg-[#0d1428]/80 p-6">
              <h2 className="mb-3 text-xl font-semibold text-white">{t.logs}</h2>
              {events.length === 0 ? (
                <p className="text-sm text-slate-400">{t.noLogs}</p>
              ) : (
                <ul className="max-h-64 space-y-2 overflow-y-auto text-xs">
                  {events.slice(0, 24).map((event) => (
                    <li key={event.id} className="rounded-lg border border-slate-700 bg-slate-950/70 p-3">
                      <div className="flex items-center justify-between gap-2">
                        <span className={`rounded-full px-2 py-0.5 text-[10px] uppercase tracking-wider ${event.level === "error" ? "bg-rose-500/20 text-rose-300" : event.level === "warn" ? "bg-amber-500/20 text-amber-300" : "bg-cyan-500/20 text-cyan-300"}`}>
                          {event.level}
                        </span>
                        <span className="text-slate-500">{new Date(event.createdAt).toLocaleTimeString()}</span>
                      </div>
                      <p className="mt-1 text-slate-200">[{event.feature}] {event.message}</p>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <section className="rounded-3xl border border-slate-700/80 bg-[#0d1428]/80 p-6">
              <h2 className="mb-3 text-xl font-semibold text-white">{t.report}</h2>
              {!report || !scoreCard ? (
                <p className="text-sm text-slate-400">{t.noReport}</p>
              ) : (
                <div className="space-y-5">
                  <div className="rounded-3xl border border-slate-700 bg-[#111a2c] p-5 shadow-[0_30px_80px_rgba(2,8,20,0.45)]">
                    <div className="mx-auto flex w-full max-w-2xl flex-col items-center gap-4">
                      <div className="relative grid h-44 w-44 place-items-center rounded-full" style={{ background: `conic-gradient(#35d07f ${gaugeDegree}deg, #1f2937 ${gaugeDegree}deg 300deg, transparent 300deg 360deg)` }}>
                        <div className="grid h-36 w-36 place-items-center rounded-full bg-[#111a2c] ring-1 ring-slate-700/80">
                          <div className="text-center">
                            <p className="text-5xl font-bold leading-none text-emerald-400">{scoreCard.score}</p>
                            <p className="mt-1 text-sm text-slate-400">/ 100</p>
                            <span className="mt-2 inline-flex rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-bold text-emerald-300">{scoreCard.grade}</span>
                          </div>
                        </div>
                      </div>
                      <p className="text-sm text-slate-300">{t.qualityScore}</p>
                    </div>

                    <div className="mt-5 grid gap-3 md:grid-cols-3">
                      <div className="rounded-2xl border border-slate-700 bg-slate-950/40 p-4 text-center"><p className="text-3xl font-bold text-white">{scoreCard.rooms}</p><p className="mt-1 text-sm text-slate-400">{isArabic ? "غرف" : "rooms"}</p></div>
                      <div className="rounded-2xl border border-slate-700 bg-slate-950/40 p-4 text-center"><p className="text-3xl font-bold text-white">{scoreCard.grossArea}</p><p className="mt-1 text-sm text-slate-400">{isArabic ? "م² إجمالي" : "m² gross"}</p></div>
                      <div className="rounded-2xl border border-slate-700 bg-slate-950/40 p-4 text-center"><p className="text-3xl font-bold text-white">${scoreCard.estimatedCost.toLocaleString()}</p><p className="mt-1 text-sm text-slate-400">{isArabic ? "تكلفة تقديرية" : "est. cost"}</p></div>
                    </div>

                    <div className="mt-5 space-y-2">
                      <h3 className="text-sm font-semibold text-slate-200">{t.findings}</h3>
                      {scoreCard.findings.map((finding, idx) => (
                        <div key={`${finding}-${idx}`} className="rounded-xl border border-slate-800 bg-[#0f1728] px-4 py-3 text-sm text-amber-200">⚠ {finding}</div>
                      ))}
                    </div>

                    <p className="mt-4 text-center text-sm text-slate-400">
                      {scoreCard.extraFindings > 0
                        ? isArabic
                          ? `+${scoreCard.extraFindings} ملاحظات إضافية متاحة في التقرير الكامل.`
                          : `+${scoreCard.extraFindings} more findings available in the full report.`
                        : isArabic
                          ? "تم تضمين كل الملاحظات الحرجة في الملخص أعلاه."
                          : "All critical findings are included in this summary."}
                    </p>

                    <button className="mt-5 w-full rounded-2xl bg-emerald-500 px-6 py-3 text-lg font-semibold text-slate-950 transition hover:bg-emerald-400">⚡ {t.fullReportCta}</button>
                  </div>

                  <div className="rounded-xl border border-slate-700 bg-slate-950/70 p-4">
                    <h3 className="text-lg font-semibold text-cyan-200">{report.title}</h3>
                    <p className="mt-1 text-sm text-slate-300">{report.summary}</p>
                    <p className="mt-2 text-xs text-slate-500">Provider: {report.provider} · Model: {report.model}</p>
                  </div>

                  <div className="grid gap-3 md:grid-cols-2">
                    {report.sections.map((section) => (
                      <article key={section.title} className="rounded-xl border border-slate-700 bg-black/30 p-4">
                        <h4 className="text-sm font-semibold text-slate-100">{section.title}</h4>
                        <ul className="mt-2 list-disc space-y-1 ps-5 text-sm text-slate-300">
                          {section.bullets.map((bullet, index) => (
                            <li key={`${section.title}-${index}`}>{bullet}</li>
                          ))}
                        </ul>
                      </article>
                    ))}
                  </div>

                  <pre className="overflow-x-auto whitespace-pre-wrap rounded-xl border border-slate-700 bg-slate-950/70 p-4 text-sm leading-7 text-slate-200">{report.markdown}</pre>
                </div>
              )}
            </section>
          </div>
        </section>
      </div>
    </main>
  );
}
