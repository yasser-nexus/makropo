import { ArchaiDashboard } from "@/components/archai-dashboard";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <ArchaiDashboard />;
}
