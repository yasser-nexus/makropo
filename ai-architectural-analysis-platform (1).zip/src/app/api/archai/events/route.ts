import { enforceRateLimit, requireBrowserIdentity } from "@/lib/api-security";
import { listEvents } from "@/lib/telemetry";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const identity = requireBrowserIdentity(req);
  if (!identity.ok) return identity.response;

  const rate = enforceRateLimit({
    scope: "events",
    ip: identity.ip,
    browserId: identity.browserId,
    max: 120,
    windowMs: 60_000,
  });
  if (!rate.ok) return rate.response;

  const { searchParams } = new URL(req.url);
  const sinceId = Number(searchParams.get("sinceId") ?? "0");
  const limit = Number(searchParams.get("limit") ?? "60");

  const events = await listEvents({
    browserId: identity.browserId,
    sinceId: Number.isFinite(sinceId) ? sinceId : 0,
    limit: Number.isFinite(limit) ? limit : 60,
  });

  return Response.json({ ok: true, events });
}
