import { generateArchitectureReport } from "@/lib/archai-service";
import { enforceRateLimit, requireBrowserIdentity, sanitizePrompt } from "@/lib/api-security";
import { saveJob } from "@/lib/job-store";
import { logEvent } from "@/lib/telemetry";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type ChatBody = {
  message?: string;
  language?: "ar" | "en";
};

export async function POST(req: Request) {
  const identity = requireBrowserIdentity(req);
  if (!identity.ok) return identity.response;

  const rate = enforceRateLimit({
    scope: "chat",
    ip: identity.ip,
    browserId: identity.browserId,
    max: 40,
    windowMs: 60_000,
  });
  if (!rate.ok) return rate.response;

  const body = (await req.json()) as ChatBody;
  const message = sanitizePrompt(body.message, "chat");
  const language = body.language === "ar" ? "ar" : "en";

  if (!message) {
    return Response.json({ ok: false, error: "message is required" }, { status: 400 });
  }

  await logEvent({
    browserId: identity.browserId,
    feature: "chat",
    message: "Architectural assistant request started",
    metadata: { promptLength: message.length },
  });

  try {
    const report = await generateArchitectureReport({
      feature: "chat",
      language,
      chatMessage: message,
      log: async (eventMessage, level = "info", metadata) => {
        await logEvent({ browserId: identity.browserId, feature: "chat", message: eventMessage, level, metadata });
      },
    });

    const job = await saveJob({
      browserId: identity.browserId,
      feature: "chat",
      language,
      prompt: message,
      result: report as unknown as Record<string, unknown>,
    });

    await logEvent({
      browserId: identity.browserId,
      feature: "chat",
      message: "Architectural assistant response completed",
      metadata: { provider: report.provider, model: report.model, jobId: job?.id ?? null },
    });

    return Response.json({ ok: true, report, job });
  } catch (error) {
    await logEvent({
      browserId: identity.browserId,
      feature: "chat",
      level: "error",
      message: "Architectural assistant request failed",
      metadata: { error: error instanceof Error ? error.message : "unknown" },
    });

    return Response.json({ ok: false, error: "assistant failed" }, { status: 500 });
  }
}
