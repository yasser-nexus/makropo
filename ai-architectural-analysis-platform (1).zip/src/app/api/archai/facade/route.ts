import { generateArchitectureReport } from "@/lib/archai-service";
import { enforceRateLimit, requireBrowserIdentity, sanitizePrompt, validateUploadedFile } from "@/lib/api-security";
import { saveJob } from "@/lib/job-store";
import { logEvent } from "@/lib/telemetry";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const identity = requireBrowserIdentity(req);
  if (!identity.ok) return identity.response;

  const rate = enforceRateLimit({
    scope: "facade",
    ip: identity.ip,
    browserId: identity.browserId,
    max: 25,
    windowMs: 60_000,
  });
  if (!rate.ok) return rate.response;

  const formData = await req.formData();
  const file = formData.get("file");
  const prompt = sanitizePrompt(String(formData.get("prompt") ?? ""), "prompt");
  const language = formData.get("language") === "ar" ? "ar" : "en";

  if (!(file instanceof File)) {
    return Response.json({ ok: false, error: "file is required" }, { status: 400 });
  }

  const validated = await validateUploadedFile(file);
  if (!validated.ok) return validated.response;

  await logEvent({
    browserId: identity.browserId,
    feature: "facade",
    message: "Facade analysis started",
    metadata: { fileName: file.name, mimeType: file.type },
  });

  try {
    const report = await generateArchitectureReport({
      feature: "facade",
      file,
      prompt,
      language,
      log: async (message, level = "info", metadata) => {
        await logEvent({ browserId: identity.browserId, feature: "facade", message, level, metadata });
      },
    });

    const job = await saveJob({
      browserId: identity.browserId,
      feature: "facade",
      language,
      inputName: file.name,
      mimeType: file.type,
      prompt,
      result: report as unknown as Record<string, unknown>,
    });

    await logEvent({
      browserId: identity.browserId,
      feature: "facade",
      message: "Facade analysis completed",
      metadata: { provider: report.provider, model: report.model, jobId: job?.id ?? null },
    });

    return Response.json({ ok: true, report, job });
  } catch (error) {
    await logEvent({
      browserId: identity.browserId,
      feature: "facade",
      level: "error",
      message: "Facade analysis failed",
      metadata: { error: error instanceof Error ? error.message : "unknown" },
    });

    return Response.json({ ok: false, error: "analysis failed" }, { status: 500 });
  }
}
