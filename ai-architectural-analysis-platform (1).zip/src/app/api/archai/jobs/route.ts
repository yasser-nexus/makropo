import { enforceRateLimit, requireBrowserIdentity } from "@/lib/api-security";
import { getRecentJobs } from "@/lib/job-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const identity = requireBrowserIdentity(req);
  if (!identity.ok) return identity.response;

  const rate = enforceRateLimit({
    scope: "jobs",
    ip: identity.ip,
    browserId: identity.browserId,
    max: 100,
    windowMs: 60_000,
  });
  if (!rate.ok) return rate.response;

  const jobs = await getRecentJobs(identity.browserId, 40);
  return Response.json({ ok: true, jobs });
}
