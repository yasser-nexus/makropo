import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "ArchAI-Core | AI Architecture Intelligence Suite",
  description:
    "AI-powered architectural analysis platform for floor plan critique, facade analysis, image-to-blueprint reverse engineering, and expert architectural chat.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar">
      <body className="min-h-screen bg-[#070b16] text-slate-100 antialiased">{children}</body>
    </html>
  );
}
