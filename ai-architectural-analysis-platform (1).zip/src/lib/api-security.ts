type RateRecord = {
  count: number;
  resetAt: number;
};

const rateStore = new Map<string, RateRecord>();

const MAX_PROMPT_LENGTH = 4000;
const MAX_CHAT_LENGTH = 5000;
const MAX_UPLOAD_SIZE_BYTES = 15 * 1024 * 1024;

const ALLOWED_UPLOAD_TYPES = new Set([
  "application/pdf",
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
]);

function now() {
  return Date.now();
}

function getClientIp(req: Request): string {
  const xff = req.headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0]?.trim() || "unknown";
  return "unknown";
}

function parseCookieValue(cookieHeader: string | null, key: string): string | null {
  if (!cookieHeader) return null;
  const cookies = cookieHeader.split(";");
  for (const item of cookies) {
    const [k, ...v] = item.trim().split("=");
    if (k === key) return decodeURIComponent(v.join("="));
  }
  return null;
}

export function getBrowserIdFromRequest(req: Request): string {
  const fromHeader = req.headers.get("x-browser-id")?.trim();
  if (fromHeader && fromHeader.length >= 12 && fromHeader.length <= 128) return fromHeader;

  const fromCookie = parseCookieValue(req.headers.get("cookie"), "archai_browser_id")?.trim();
  if (fromCookie && fromCookie.length >= 12 && fromCookie.length <= 128) return fromCookie;

  return "anonymous-browser";
}

function keyForRateLimit(ip: string, browserId: string, scope: string): string {
  return `${scope}:${browserId}:${ip}`;
}

export function requireBrowserIdentity(req: Request):
  | {
      ok: true;
      browserId: string;
      ip: string;
    }
  | {
      ok: false;
      response: Response;
    } {
  const browserId = getBrowserIdFromRequest(req);
  const ip = getClientIp(req);

  if (browserId === "anonymous-browser") {
    return {
      ok: false,
      response: Response.json(
        {
          ok: false,
          error: "Browser identity missing. Refresh the page and retry.",
          code: "BROWSER_ID_REQUIRED",
        },
        { status: 400 },
      ),
    };
  }

  return { ok: true, browserId, ip };
}

export function enforceRateLimit(input: {
  scope: string;
  ip: string;
  browserId: string;
  max: number;
  windowMs: number;
}): { ok: true } | { ok: false; response: Response } {
  const key = keyForRateLimit(input.ip, input.browserId, input.scope);
  const current = rateStore.get(key);
  const time = now();

  if (!current || current.resetAt < time) {
    rateStore.set(key, { count: 1, resetAt: time + input.windowMs });
    return { ok: true };
  }

  if (current.count >= input.max) {
    return {
      ok: false,
      response: Response.json(
        {
          ok: false,
          error: "Too many requests. Please wait before retrying.",
          code: "RATE_LIMITED",
          retryAfterMs: Math.max(0, current.resetAt - time),
        },
        {
          status: 429,
          headers: {
            "Retry-After": Math.ceil(Math.max(0, current.resetAt - time) / 1000).toString(),
          },
        },
      ),
    };
  }

  current.count += 1;
  rateStore.set(key, current);
  return { ok: true };
}

export function sanitizePrompt(raw: string | undefined, kind: "prompt" | "chat" = "prompt"): string {
  const max = kind === "chat" ? MAX_CHAT_LENGTH : MAX_PROMPT_LENGTH;
  const normalized = (raw ?? "")
    .replace(/[\u0000-\u001F\u007F]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  return normalized.slice(0, max);
}

export async function validateUploadedFile(file: File): Promise<{ ok: true } | { ok: false; response: Response }> {
  if (!ALLOWED_UPLOAD_TYPES.has(file.type.toLowerCase())) {
    return {
      ok: false,
      response: Response.json(
        {
          ok: false,
          error: "Unsupported file type. Allowed: PDF, PNG, JPG, WEBP.",
          code: "INVALID_FILE_TYPE",
        },
        { status: 400 },
      ),
    };
  }

  if (file.size > MAX_UPLOAD_SIZE_BYTES) {
    return {
      ok: false,
      response: Response.json(
        {
          ok: false,
          error: "File too large. Maximum allowed size is 15MB.",
          code: "FILE_TOO_LARGE",
        },
        { status: 413 },
      ),
    };
  }

  if (file.name.length > 220) {
    return {
      ok: false,
      response: Response.json(
        {
          ok: false,
          error: "File name too long.",
          code: "FILE_NAME_INVALID",
        },
        { status: 400 },
      ),
    };
  }

  return { ok: true };
}
