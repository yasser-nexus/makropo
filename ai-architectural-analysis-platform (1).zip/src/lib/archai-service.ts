import { getSystemPrompt, getUserPrompt } from "@/lib/archai-prompts";
import { generateHeuristicReport } from "@/lib/heuristic-engine";
import { formatInsightsForPrompt, gatherInternetInsights } from "@/lib/internet-research";
import type { AnalysisReport, FeatureKey } from "@/lib/archai-types";

const OPENAI_URL = "https://api.openai.com/v1/chat/completions";
const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models";

type LogFn = (message: string, level?: "info" | "warn" | "error", metadata?: Record<string, unknown>) => Promise<void>;

type GenerateParams = {
  feature: FeatureKey;
  language: "ar" | "en";
  prompt?: string;
  file?: File;
  chatMessage?: string;
  log?: LogFn;
};

type OpenAiMessage = {
  role: "system" | "user" | "assistant";
  content: string | Array<Record<string, unknown>>;
};

function parseJsonSafe(input: string): unknown {
  try {
    return JSON.parse(input);
  } catch {
    return input;
  }
}

function normalizeReport(
  raw: unknown,
  language: "ar" | "en",
  model: string,
  provider: AnalysisReport["provider"],
): AnalysisReport {
  const fallback: AnalysisReport = {
    title: language === "ar" ? "تقرير التحليل" : "Analysis Report",
    summary:
      language === "ar"
        ? "تم إنشاء تقرير مبدئي."
        : "A preliminary report has been generated.",
    sections: [],
    markdown: typeof raw === "string" ? raw : JSON.stringify(raw, null, 2),
    language,
    model,
    provider,
  };

  if (!raw || typeof raw !== "object") return fallback;
  const maybe = raw as Partial<AnalysisReport> & { sections?: unknown };

  return {
    title: typeof maybe.title === "string" ? maybe.title : fallback.title,
    summary: typeof maybe.summary === "string" ? maybe.summary : fallback.summary,
    sections: Array.isArray(maybe.sections)
      ? maybe.sections
          .map((s) => {
            if (!s || typeof s !== "object") return null;
            const section = s as { title?: unknown; bullets?: unknown };
            return {
              title: typeof section.title === "string" ? section.title : "Section",
              bullets: Array.isArray(section.bullets)
                ? section.bullets.filter((b): b is string => typeof b === "string")
                : [],
            };
          })
          .filter((s): s is { title: string; bullets: string[] } => Boolean(s))
      : [],
    markdown: typeof maybe.markdown === "string" ? maybe.markdown : fallback.markdown,
    language,
    model,
    provider,
  };
}

function buildFallback(feature: FeatureKey, language: "ar" | "en", note: string): AnalysisReport {
  const titles: Record<FeatureKey, { ar: string; en: string }> = {
    "floor-plan": { ar: "تقييم المخطط", en: "Floor Plan Evaluation" },
    facade: { ar: "تحليل الواجهة", en: "Facade Analysis" },
    "reverse-engineer": { ar: "استخراج مخطط من صورة", en: "Image-to-Blueprint Strategy" },
    chat: { ar: "المساعد المعماري", en: "Architectural Assistant" },
  };

  const markdown =
    language === "ar"
      ? `## ملاحظة تشغيلية\n${note}\n\n## الخطوة التالية\nأضف مزوّدًا عالميًا مثل OPENAI_API_KEY أو OPENROUTER_API_KEY أو GOOGLE_API_KEY.`
      : `## Operational Note\n${note}\n\n## Next Step\nConfigure a global provider such as OPENAI_API_KEY, OPENROUTER_API_KEY, or GOOGLE_API_KEY.`;

  return {
    title: titles[feature][language],
    summary: language === "ar" ? "وضع تجريبي محدود." : "Limited fallback mode.",
    sections: [
      {
        title: language === "ar" ? "الحالة" : "Status",
        bullets: [note],
      },
    ],
    markdown,
    language,
    model: "fallback",
    provider: "fallback",
  };
}

async function getVisionContent(file?: File): Promise<Array<Record<string, unknown>>> {
  if (!file) return [];
  if (!file.type.startsWith("image/")) return [];

  const buffer = Buffer.from(await file.arrayBuffer());
  const base64 = buffer.toString("base64");
  const url = `data:${file.type};base64,${base64}`;

  return [{ type: "image_url", image_url: { url } }];
}

async function tryPythonService(params: GenerateParams): Promise<AnalysisReport | null> {
  const baseUrl = process.env.ARCHAI_PYTHON_API_URL;
  if (!baseUrl) return null;

  await params.log?.("Attempting FastAPI multimodal provider", "info", { provider: "python-service" });

  const endpoint =
    params.feature === "chat"
      ? `${baseUrl.replace(/\/$/, "")}/v1/chat`
      : `${baseUrl.replace(/\/$/, "")}/v1/analyze/${params.feature}`;

  let res: Response;

  if (params.feature === "chat") {
    res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: params.chatMessage,
        prompt: params.prompt,
        language: params.language,
      }),
    });
  } else {
    const fd = new FormData();
    if (params.file) fd.append("file", params.file);
    if (params.prompt) fd.append("prompt", params.prompt);
    fd.append("language", params.language);

    res = await fetch(endpoint, { method: "POST", body: fd });
  }

  if (!res.ok) {
    await params.log?.("Python provider returned non-200", "warn", { status: res.status });
    throw new Error(`Python service failed (${res.status})`);
  }

  const data = (await res.json()) as unknown;
  await params.log?.("Python provider completed successfully", "info");
  return normalizeReport(data, params.language, "python-service", "python-service");
}

async function callOpenAiCompatible(params: {
  url: string;
  apiKey: string;
  model: string;
  messages: OpenAiMessage[];
  temperature?: number;
  headers?: Record<string, string>;
}): Promise<string> {
  const response = await fetch(params.url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${params.apiKey}`,
      ...(params.headers || {}),
    },
    body: JSON.stringify({
      model: params.model,
      temperature: params.temperature ?? 0.2,
      response_format: { type: "json_object" },
      messages: params.messages,
    }),
  });

  if (!response.ok) {
    throw new Error(`Provider request failed (${response.status})`);
  }

  const json = (await response.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };

  const rawContent = json.choices?.[0]?.message?.content;
  if (!rawContent) throw new Error("Provider returned empty content");
  return rawContent;
}

async function runAgenticChainWithOpenAiCompatible(params: {
  providerName: "openai" | "openrouter";
  providerUrl: string;
  apiKey: string;
  model: string;
  input: GenerateParams;
  headers?: Record<string, string>;
  internetContext: string;
}): Promise<AnalysisReport> {
  const systemPrompt = getSystemPrompt(params.input.feature, params.input.language);
  const baseUserText =
    params.input.feature === "chat"
      ? getUserPrompt("chat", params.input.chatMessage ?? params.input.prompt, params.input.language)
      : getUserPrompt(params.input.feature, params.input.prompt, params.input.language);

  const content: Array<Record<string, unknown>> = [{ type: "text", text: `${baseUserText}\n\n${params.internetContext}` }];

  const vision = await getVisionContent(params.input.file);
  if (vision.length > 0) content.push(...vision);

  await params.input.log?.(`${params.providerName} stage 1/3: Planner`, "info", { model: params.model });
  const plannerRaw = await callOpenAiCompatible({
    url: params.providerUrl,
    apiKey: params.apiKey,
    model: params.model,
    headers: params.headers,
    messages: [
      { role: "system", content: `${systemPrompt}\n\nYou are now in planning mode.` },
      {
        role: "user",
        content: [
          ...content,
          {
            type: "text",
            text:
              params.input.language === "ar"
                ? "أنشئ خطة تحليلية صارمة تشمل الفرضيات، معايير التقييم، وخطوات الاستدلال الفني."
                : "Create a strict analysis plan including assumptions, evaluation criteria, and reasoning steps.",
          },
        ],
      },
    ],
  });

  await params.input.log?.(`${params.providerName} stage 2/3: Critic`, "info", { model: params.model });
  const criticRaw = await callOpenAiCompatible({
    url: params.providerUrl,
    apiKey: params.apiKey,
    model: params.model,
    headers: params.headers,
    messages: [
      { role: "system", content: `${systemPrompt}\n\nYou are now in critic mode.` },
      {
        role: "user",
        content:
          params.input.language === "ar"
            ? `راجع الخطة التالية بنقد صارم وحدد الفجوات:\n${plannerRaw}`
            : `Critically review this plan and identify gaps:\n${plannerRaw}`,
      },
    ],
  });

  await params.input.log?.(`${params.providerName} stage 3/3: Synthesis`, "info", { model: params.model });
  const synthesisRaw = await callOpenAiCompatible({
    url: params.providerUrl,
    apiKey: params.apiKey,
    model: params.model,
    headers: params.headers,
    messages: [
      { role: "system", content: `${systemPrompt}\n\nSynthesize final user-facing report.` },
      {
        role: "user",
        content:
          params.input.language === "ar"
            ? `المدخلات:\n- طلب المستخدم: ${baseUserText}\n- خطة التحليل: ${plannerRaw}\n- المراجعة النقدية: ${criticRaw}\n- مرجع الإنترنت: ${params.internetContext}\n\nأخرج التقرير النهائي بصيغة JSON المحددة.`
            : `Inputs:\n- User ask: ${baseUserText}\n- Analysis plan: ${plannerRaw}\n- Critical review: ${criticRaw}\n- Internet reference: ${params.internetContext}\n\nReturn the final report using required JSON schema.`,
      },
    ],
  });

  const parsed = parseJsonSafe(synthesisRaw);
  const provider = params.providerName === "openrouter" ? "openrouter" : "openai";
  return normalizeReport(parsed, params.input.language, params.model, provider);
}

async function tryOpenAI(params: GenerateParams, internetContext: string): Promise<AnalysisReport | null> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return null;

  const model = process.env.ARCHAI_OPENAI_MODEL || "gpt-4o-mini";
  await params.log?.("OpenAI provider selected", "info", { model });

  return runAgenticChainWithOpenAiCompatible({
    providerName: "openai",
    providerUrl: OPENAI_URL,
    apiKey,
    model,
    input: params,
    internetContext,
  });
}

async function tryOpenRouter(params: GenerateParams, internetContext: string): Promise<AnalysisReport | null> {
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) return null;

  const model = process.env.ARCHAI_OPENROUTER_MODEL || "openai/gpt-4o-mini";
  await params.log?.("OpenRouter provider selected", "info", { model });

  return runAgenticChainWithOpenAiCompatible({
    providerName: "openrouter",
    providerUrl: OPENROUTER_URL,
    apiKey,
    model,
    input: params,
    internetContext,
    headers: {
      "HTTP-Referer": process.env.NEXT_PUBLIC_APP_URL || "https://archai-core.local",
      "X-Title": "ArchAI-Core",
    },
  });
}

async function callGeminiJSON(params: {
  apiKey: string;
  model: string;
  systemPrompt: string;
  userText: string;
  imagePart?: { mimeType: string; data: string };
}): Promise<string> {
  const url = `${GEMINI_BASE}/${params.model}:generateContent?key=${params.apiKey}`;

  const parts: Array<Record<string, unknown>> = [
    { text: `${params.systemPrompt}\n\n${params.userText}\n\nReturn JSON only.` },
  ];

  if (params.imagePart) {
    parts.push({
      inline_data: {
        mime_type: params.imagePart.mimeType,
        data: params.imagePart.data,
      },
    });
  }

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      generationConfig: {
        temperature: 0.2,
      },
      contents: [{ role: "user", parts }],
    }),
  });

  if (!res.ok) {
    throw new Error(`Gemini request failed (${res.status})`);
  }

  const data = (await res.json()) as {
    candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
  };

  const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error("Gemini returned empty content");
  return text;
}

async function tryGemini(params: GenerateParams, internetContext: string): Promise<AnalysisReport | null> {
  const apiKey = process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY;
  if (!apiKey) return null;

  const model = process.env.ARCHAI_GEMINI_MODEL || "gemini-1.5-pro";
  await params.log?.("Gemini provider selected", "info", { model });

  const systemPrompt = getSystemPrompt(params.feature, params.language);
  const baseUserText =
    params.feature === "chat"
      ? getUserPrompt("chat", params.chatMessage ?? params.prompt, params.language)
      : getUserPrompt(params.feature, params.prompt, params.language);

  let imagePart: { mimeType: string; data: string } | undefined;
  if (params.file && params.file.type.startsWith("image/")) {
    const buffer = Buffer.from(await params.file.arrayBuffer());
    imagePart = { mimeType: params.file.type, data: buffer.toString("base64") };
  }

  await params.log?.("Gemini stage 1/3: Planner", "info");
  const planner = await callGeminiJSON({
    apiKey,
    model,
    systemPrompt,
    userText: `${baseUserText}\n${internetContext}\nCreate strict planning JSON.`,
    imagePart,
  });

  await params.log?.("Gemini stage 2/3: Critic", "info");
  const critic = await callGeminiJSON({
    apiKey,
    model,
    systemPrompt,
    userText: `Critique this plan and list gaps:\n${planner}`,
  });

  await params.log?.("Gemini stage 3/3: Synthesis", "info");
  const synthesis = await callGeminiJSON({
    apiKey,
    model,
    systemPrompt,
    userText: `${baseUserText}\nInternet context:\n${internetContext}\nPlan:\n${planner}\nCritic:\n${critic}\nReturn final JSON report.`,
    imagePart,
  });

  const parsed = parseJsonSafe(synthesis);
  return normalizeReport(parsed, params.language, model, "gemini");
}

export async function generateArchitectureReport(params: GenerateParams): Promise<AnalysisReport> {
  await params.log?.("Collecting live internet insights", "info");
  const insights = await gatherInternetInsights({
    feature: params.feature,
    language: params.language,
    prompt: params.prompt,
    chatMessage: params.chatMessage,
  });
  const internetContext = formatInsightsForPrompt(insights, params.language);
  await params.log?.("Internet insights collected", "info", { count: insights.length });

  try {
    const pythonResult = await tryPythonService(params);
    if (pythonResult) return pythonResult;
  } catch (error) {
    await params.log?.("Python provider failed, switching provider", "warn", {
      error: error instanceof Error ? error.message : "unknown",
    });
  }

  try {
    const openAiResult = await tryOpenAI(params, internetContext);
    if (openAiResult) return openAiResult;
  } catch (error) {
    await params.log?.("OpenAI provider failed", "warn", {
      error: error instanceof Error ? error.message : "unknown",
    });
  }

  try {
    const openRouterResult = await tryOpenRouter(params, internetContext);
    if (openRouterResult) return openRouterResult;
  } catch (error) {
    await params.log?.("OpenRouter provider failed", "warn", {
      error: error instanceof Error ? error.message : "unknown",
    });
  }

  try {
    const geminiResult = await tryGemini(params, internetContext);
    if (geminiResult) return geminiResult;
  } catch (error) {
    await params.log?.("Gemini provider failed", "warn", {
      error: error instanceof Error ? error.message : "unknown",
    });
  }

  try {
    await params.log?.("Local heuristic engine started", "warn", { engine: "archai-heuristic-v1" });
    const localReport = await generateHeuristicReport({
      ...params,
      prompt: `${params.prompt ?? ""}\n\n${internetContext}`.trim(),
      chatMessage: `${params.chatMessage ?? ""}\n\n${internetContext}`.trim(),
    });
    await params.log?.("Local heuristic engine completed", "info", { provider: "local-heuristic" });
    return localReport;
  } catch (error) {
    await params.log?.("Local heuristic engine failed, switching to static fallback", "error", {
      error: error instanceof Error ? error.message : "unknown",
    });
  }

  const report = buildFallback(
    params.feature,
    params.language,
    params.language === "ar"
      ? "تعذّر تشغيل جميع المزوّدات الخارجية والمحرك المحلي حالياً."
      : "All external providers and local engine are currently unavailable.",
  );

  await params.log?.("Static fallback report generated", "warn");
  return report;
}
