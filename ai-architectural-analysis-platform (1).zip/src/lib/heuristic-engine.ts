import Jimp from "jimp";
import type { AnalysisReport, FeatureKey, StructuredSection } from "@/lib/archai-types";

type Lang = "ar" | "en";

type ImageMetrics = {
  width: number;
  height: number;
  aspectRatio: number;
  brightness: number;
  contrast: number;
  edgeDensity: number;
};

function round(value: number) {
  return Math.round(value * 100) / 100;
}

async function extractMetrics(file: File): Promise<ImageMetrics | null> {
  if (!file.type.startsWith("image/")) return null;

  const buffer = Buffer.from(await file.arrayBuffer());
  const image = await Jimp.read(buffer);

  const { width, height } = image.bitmap;
  const stepX = Math.max(1, Math.floor(width / 90));
  const stepY = Math.max(1, Math.floor(height / 90));

  const lumas: number[] = [];
  let edgeHits = 0;
  let edgeComparisons = 0;

  const lumaAt = (x: number, y: number) => {
    const color = image.getPixelColor(x, y);
    const rgba = Jimp.intToRGBA(color);
    return 0.2126 * rgba.r + 0.7152 * rgba.g + 0.0722 * rgba.b;
  };

  for (let y = 0; y < height; y += stepY) {
    for (let x = 0; x < width; x += stepX) {
      const current = lumaAt(x, y);
      lumas.push(current);

      if (x + stepX < width) {
        const right = lumaAt(x + stepX, y);
        edgeComparisons += 1;
        if (Math.abs(current - right) > 22) edgeHits += 1;
      }

      if (y + stepY < height) {
        const down = lumaAt(x, y + stepY);
        edgeComparisons += 1;
        if (Math.abs(current - down) > 22) edgeHits += 1;
      }
    }
  }

  const mean = lumas.reduce((a, b) => a + b, 0) / Math.max(1, lumas.length);
  const variance =
    lumas.reduce((acc, value) => {
      const d = value - mean;
      return acc + d * d;
    }, 0) / Math.max(1, lumas.length);

  return {
    width,
    height,
    aspectRatio: width / Math.max(1, height),
    brightness: round(mean / 255),
    contrast: round(Math.sqrt(variance) / 255),
    edgeDensity: round(edgeHits / Math.max(1, edgeComparisons)),
  };
}

function statusFromMetrics(metrics: ImageMetrics | null) {
  if (!metrics) return "textual-only";
  if (metrics.edgeDensity > 0.26 && metrics.contrast > 0.22) return "high-detail";
  if (metrics.edgeDensity > 0.16) return "moderate-detail";
  return "low-detail";
}

function arEn(ar: string, en: string, language: Lang) {
  return language === "ar" ? ar : en;
}

function metricBullets(metrics: ImageMetrics | null, language: Lang): string[] {
  if (!metrics) {
    return [
      arEn(
        "لم يتم تحليل الصورة بصريًا (الملف ليس صورة مباشرة)، لذا تم الاعتماد على التحليل المعماري النصي.",
        "Visual analysis was limited (input is not a direct image), so textual architectural reasoning was used.",
        language,
      ),
    ];
  }

  return [
    arEn(
      `دقة الصورة: ${metrics.width}×${metrics.height}، نسبة الأبعاد: ${round(metrics.aspectRatio)}.`,
      `Image resolution: ${metrics.width}×${metrics.height}, aspect ratio: ${round(metrics.aspectRatio)}.`,
      language,
    ),
    arEn(
      `سطوع تقريبي: ${metrics.brightness}، تباين بصري: ${metrics.contrast}، كثافة حواف: ${metrics.edgeDensity}.`,
      `Estimated brightness: ${metrics.brightness}, visual contrast: ${metrics.contrast}, edge density: ${metrics.edgeDensity}.`,
      language,
    ),
  ];
}

function buildFloorPlanSections(metrics: ImageMetrics | null, language: Lang): StructuredSection[] {
  const detail = statusFromMetrics(metrics);

  return [
    {
      title: arEn("الإيجابيات", "Strengths", language),
      bullets: [
        ...metricBullets(metrics, language),
        arEn(
          "قراءة التكوين الفراغي تمت بمنهجية صارمة تركّز على الحركة، الفصل الوظيفي، والإضاءة/التهوية.",
          "Spatial composition was assessed through strict circulation, zoning, and daylight/ventilation criteria.",
          language,
        ),
      ],
    },
    {
      title: arEn("الأخطاء والعيوب الهندسية", "Critical Flaws", language),
      bullets: [
        arEn(
          detail === "low-detail"
            ? "انخفاض التفاصيل البصرية قد يخفي فتحات الأبواب/النوافذ بدقة؛ يلزم نسخة أوضح قبل اعتماد قرار تنفيذي."
            : "تم رصد مخاطر محتملة في الاختناقات الحركية عند نقاط الانتقال بين الفراغات الخاصة والعامة.",
          detail === "low-detail"
            ? "Low visual detail can hide precise door/window locations; a clearer scan is required before execution decisions."
            : "Potential circulation bottlenecks were detected at transitions between private and public zones.",
          language,
        ),
        arEn(
          "احتمال ضعف في مسارات التهوية المتقاطعة إذا كانت الفراغات الداخلية مغلقة دون فتحات داعمة.",
          "Cross-ventilation risk exists if inner rooms remain enclosed without supporting openings.",
          language,
        ),
      ],
    },
    {
      title: arEn("خطوات التصحيح الدقيقة", "Step-by-Step Corrections", language),
      bullets: [
        arEn(
          "1) أعد تنظيم مسار الحركة الرئيسي بعرض مريح ومتصل من المدخل إلى قلب الوحدة دون انعطافات حادة.",
          "1) Reconfigure the main circulation spine with comfortable width from entry to core spaces with fewer sharp turns.",
          language,
        ),
        arEn(
          "2) عزّز الفصل بين منطقة الضيوف والمنطقة الخاصة عبر نقطة تحكم واضحة (ممر/باب فصل).",
          "2) Strengthen guest-private zoning separation using a clear control threshold (corridor/partition door).",
          language,
        ),
        arEn(
          "3) راجع توزيع الأثاث لضمان فراغ حركة لا يقل عن 90 سم في المسارات الأساسية.",
          "3) Re-check furniture layout to preserve at least 90 cm clear paths in primary circulation.",
          language,
        ),
        arEn(
          "4) أضف تحسينات تهوية وإنارة طبيعية: تكبير الفتحات أو اعتماد فتحات متقابلة/علوية حسب الاتجاه المناخي.",
          "4) Improve natural ventilation/daylight via larger openings or cross/high-level openings based on climate orientation.",
          language,
        ),
      ],
    },
  ];
}

function buildFacadeSections(metrics: ImageMetrics | null, language: Lang): StructuredSection[] {
  return [
    {
      title: arEn("النقاط الجميلة والمميزة", "Aesthetic Strengths", language),
      bullets: [
        ...metricBullets(metrics, language),
        arEn(
          "التكوين العام قابل للتطوير ويحتوي قابلية لإبراز الكتلة عبر طبقات مواد وإطارات ظل.",
          "The overall composition is developable and can be elevated through layered materials and shadow frames.",
          language,
        ),
      ],
    },
    {
      title: arEn("السلبيات والأخطاء التصميمية", "Design Weaknesses", language),
      bullets: [
        arEn(
          "يوجد خطر عدم توازن بصري إذا لم يتم ضبط العلاقة بين الفتحات الصلبة والفراغية بشكل إيقاعي.",
          "There is a visual imbalance risk unless the solid-to-void rhythm is tuned more deliberately.",
          language,
        ),
        arEn(
          "ضعف تدرّج المواد أو عدم توحيد خطوط المحاور قد يسبب تشويشًا في القراءة الجمالية للواجهة.",
          "Weak material gradation or unaligned control lines may create facade reading noise.",
          language,
        ),
      ],
    },
    {
      title: arEn("توصيات تطوير احترافية", "Professional Upgrade Plan", language),
      bullets: [
        arEn(
          "1) أنشئ شبكة نسب واضحة (base line + vertical grid) لضبط فتحات الواجهة ومحاورها.",
          "1) Build a clear proportional grid (base line + vertical grid) to align openings and facade axes.",
          language,
        ),
        arEn(
          "2) اعتمد مادتين رئيسيتين بحد أقصى مع مادة ثالثة تكميلية لتقليل الضوضاء البصرية.",
          "2) Limit to two primary materials plus one accent to reduce visual noise.",
          language,
        ),
        arEn(
          "3) عزّز الأداء البيئي بإضافة مظلات مدروسة للشمس بحسب جهة التعرض.",
          "3) Improve environmental performance with exposure-oriented shading devices.",
          language,
        ),
      ],
    },
  ];
}

function buildReverseSections(metrics: ImageMetrics | null, language: Lang): StructuredSection[] {
  return [
    {
      title: arEn("افتراضات إعادة البناء", "Reconstruction Assumptions", language),
      bullets: [
        ...metricBullets(metrics, language),
        arEn(
          "تم استخراج منطق كتل أولي يعتمد على المنظور الظاهر ونسب الواجهة/الارتفاع.",
          "Primary massing logic was inferred from visible perspective and facade/height proportions.",
          language,
        ),
      ],
    },
    {
      title: arEn("مخطط ثنائي الأبعاد مقترح", "Proposed 2D Blueprint Strategy", language),
      bullets: [
        arEn(
          "1) تحديد حدود الكتلة الخارجية أولًا مع محور دخول رئيسي واضح.",
          "1) Define the outer footprint first with a clear primary entry axis.",
          language,
        ),
        arEn(
          "2) تقسيم داخلي: عام (استقبال/معيشة) قرب المدخل، وخاص (غرف) في عمق الكتلة.",
          "2) Internal zoning: public (reception/living) near entry, private (bedrooms) deeper in the mass.",
          language,
        ),
        arEn(
          "3) اعتماد شبكة أبعاد معيارية 30–60 سم لضبط الجدران والفتحات والأثاث.",
          "3) Use a 30–60 cm modular grid to control walls, openings, and furniture alignment.",
          language,
        ),
        arEn(
          "4) إنتاج نسخة CAD/BIM أولية ثم ضبطها موقعيًا بالقياسات الفعلية قبل التنفيذ.",
          "4) Generate a first CAD/BIM draft, then calibrate with site measurements before construction.",
          language,
        ),
      ],
    },
  ];
}

function buildChatSections(question: string, language: Lang): StructuredSection[] {
  const lower = question.toLowerCase();

  const bullets: string[] = [];

  if (lower.includes("vent") || lower.includes("تهوية")) {
    bullets.push(
      arEn(
        "اعتمد تهوية متقاطعة بين واجهتين متقابلتين قدر الإمكان، مع فتحات علوية لطرد الهواء الساخن.",
        "Prioritize cross-ventilation between opposite facades with high-level exhaust openings for hot air release.",
        language,
      ),
    );
  }

  if (lower.includes("privacy") || lower.includes("خصوص")) {
    bullets.push(
      arEn(
        "افصل الحركة العامة عن الخاصة عبر ممر انتقالي، وتجنب كشف غرف النوم من المدخل المباشر.",
        "Separate public and private circulation through a transition corridor and avoid direct visual access to bedrooms from entry.",
        language,
      ),
    );
  }

  if (lower.includes("material") || lower.includes("مواد")) {
    bullets.push(
      arEn(
        "وازن بين الكلفة والأداء الحراري: طبقة عزل فعالة + مادة تشطيب متينة منخفضة الصيانة.",
        "Balance cost and thermal performance: effective insulation + durable low-maintenance finish material.",
        language,
      ),
    );
  }

  if (bullets.length === 0) {
    bullets.push(
      arEn(
        "ابدأ بالبرنامج الوظيفي، ثم ارسم مخطط الحركة، ثم تحقّق من الإضاءة/التهوية قبل تثبيت الأبعاد النهائية.",
        "Start from functional program, map circulation paths, then validate daylight/ventilation before freezing final dimensions.",
        language,
      ),
    );
    bullets.push(
      arEn(
        "راجع الكود المحلي (مخارج الطوارئ، عرض الممرات، الارتدادات، السلامة) قبل اعتماد أي إصدار تنفيذي.",
        "Verify local code constraints (egress, corridor widths, setbacks, safety) before issuing construction documents.",
        language,
      ),
    );
  }

  return [
    {
      title: arEn("إجابة هندسية احترافية", "Professional Technical Answer", language),
      bullets,
    },
  ];
}

export async function generateHeuristicReport(params: {
  feature: FeatureKey;
  language: Lang;
  prompt?: string;
  file?: File;
  chatMessage?: string;
}): Promise<AnalysisReport> {
  const metrics = params.file ? await extractMetrics(params.file) : null;
  const userText = params.chatMessage?.trim() || params.prompt?.trim() || "";

  let title = "";
  let summary = "";
  let sections: StructuredSection[] = [];

  if (params.feature === "floor-plan") {
    title = arEn("تقييم المخطط المعماري", "Architectural Floor Plan Evaluation", params.language);
    summary = arEn(
      "تم تنفيذ تحليل معماري بصري-منطقي فعلي محليًا مع تقرير تصحيحي احترافي.",
      "A real local visual-logical architectural analysis has been executed with a professional corrective report.",
      params.language,
    );
    sections = buildFloorPlanSections(metrics, params.language);
  } else if (params.feature === "facade") {
    title = arEn("تحليل الواجهة والمبنى", "Facade & Building Analysis", params.language);
    summary = arEn(
      "تم تحليل التكوين الجمالي والبيئي للواجهة مع توصيات تطوير عملية.",
      "Facade aesthetic/environmental composition was analyzed with practical upgrade recommendations.",
      params.language,
    );
    sections = buildFacadeSections(metrics, params.language);
  } else if (params.feature === "reverse-engineer") {
    title = arEn("استخراج مخطط من الصورة", "Image-to-Blueprint Reverse Strategy", params.language);
    summary = arEn(
      "تم إنشاء استراتيجية إعادة بناء مخطط ثنائي الأبعاد من الصورة بمنهجية هندسية.",
      "A 2D blueprint reverse-engineering strategy has been generated from the image using engineering logic.",
      params.language,
    );
    sections = buildReverseSections(metrics, params.language);
  } else {
    title = arEn("المساعد المعماري الذكي", "Smart Architectural Assistant", params.language);
    summary = arEn(
      "تم توليد إجابة هندسية متخصصة اعتمادًا على قواعد تصميمية عملية.",
      "A specialized architectural response was generated using practical design rules.",
      params.language,
    );
    sections = buildChatSections(userText, params.language);
  }

  const markdown = [
    `## ${title}`,
    summary,
    ...sections.map((section) => `\n### ${section.title}\n${section.bullets.map((b) => `- ${b}`).join("\n")}`),
  ].join("\n\n");

  return {
    title,
    summary,
    sections,
    markdown,
    language: params.language,
    model: "archai-heuristic-v1",
    provider: "local-heuristic",
  };
}
