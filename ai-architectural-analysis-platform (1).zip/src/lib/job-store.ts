import { db } from "@/db";
import { analysisJobs } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function saveJob(input: {
  browserId: string;
  feature: string;
  language: "ar" | "en";
  inputName?: string;
  mimeType?: string;
  prompt?: string;
  result: Record<string, unknown>;
}) {
  try {
    const inserted = await db
      .insert(analysisJobs)
      .values({
        browserId: input.browserId,
        feature: input.feature,
        language: input.language,
        inputName: input.inputName,
        mimeType: input.mimeType,
        prompt: input.prompt,
        status: "completed",
        result: input.result,
      })
      .returning({ id: analysisJobs.id, createdAt: analysisJobs.createdAt });

    return inserted[0] ?? null;
  } catch {
    return null;
  }
}

export async function getRecentJobs(browserId: string, limit = 30) {
  try {
    return await db
      .select({
        id: analysisJobs.id,
        feature: analysisJobs.feature,
        language: analysisJobs.language,
        inputName: analysisJobs.inputName,
        status: analysisJobs.status,
        createdAt: analysisJobs.createdAt,
      })
      .from(analysisJobs)
      .where(eq(analysisJobs.browserId, browserId))
      .orderBy(desc(analysisJobs.createdAt))
      .limit(limit);
  } catch {
    return [];
  }
}
