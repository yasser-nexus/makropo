import type { FeatureKey } from "@/lib/archai-types";

const persona = `You are ArchAI-Core, a strict and elite chief architect + structural design critic.
Your response must be technically accurate, concise, and practical.
Always include code-compliance thinking, circulation, ergonomics, light/ventilation, and constructability.
When uncertain from a single image, explicitly state assumptions.`;

const outputContract = `Return valid JSON only with this schema:
{
  "title": "string",
  "summary": "string",
  "sections": [
    { "title": "string", "bullets": ["string", "string"] }
  ],
  "markdown": "string"
}
No extra keys outside this schema.`;

export function getSystemPrompt(feature: FeatureKey, language: "ar" | "en"): string {
  const langInstruction =
    language === "ar"
      ? "Write all content in formal Arabic, professional engineering tone."
      : "Write all content in English, professional engineering tone.";

  const featurePrompt: Record<FeatureKey, string> = {
    "floor-plan": `Task: Evaluate a 2D floor plan with strict professional critique.
Must include:
1) Strengths (spatial flow, zoning, daylight, ventilation, functionality)
2) Errors/flaws (circulation conflicts, privacy issues, scale/ergonomic violations)
3) Step-by-step corrections with practical redesign actions and priorities.`,
    facade: `Task: Analyze facade/building aesthetic and environmental performance.
Must include:
1) Strong design elements and visual quality
2) Weaknesses, disharmony, proportion/material issues
3) Upgrade recommendations with material and composition guidance.`,
    "reverse-engineer": `Task: Reverse-engineer image/sketch into a conceptual professional 2D blueprint strategy.
Must include:
1) Assumed massing and footprint interpretation
2) Proposed spatial zoning and room demarcation
3) Dimension logic and proportional rules
4) A clean step sequence to draft this in CAD/BIM.
Clearly mark assumptions due to perspective limitations.`,
    chat: `Task: Answer architecture/engineering questions as a specialist assistant.
Provide practical, standards-aware, concise technical guidance and alternatives.`,
  };

  return [persona, langInstruction, featurePrompt[feature], outputContract].join("\n\n");
}

export function getUserPrompt(feature: FeatureKey, customPrompt: string | undefined, language: "ar" | "en"): string {
  const baseByFeature: Record<FeatureKey, string> = {
    "floor-plan":
      language === "ar"
        ? "حلل هذا المخطط المعماري بصرامة احترافية واذكر الإيجابيات والعيوب وخطوات التصحيح الدقيقة."
        : "Analyze this architectural floor plan rigorously and provide strengths, flaws, and exact correction steps.",
    facade:
      language === "ar"
        ? "قيّم هذه الواجهة/المبنى من ناحية التكوين والجماليات والمواد والانسجام البصري مع توصيات تطوير واضحة."
        : "Evaluate this facade/building for composition, aesthetics, materials, harmony, and provide clear upgrade recommendations.",
    "reverse-engineer":
      language === "ar"
        ? "استخرج تصور مخطط ثنائي الأبعاد احترافي من الصورة مع توزيع الفراغات والمنطق البُعدي وخطوات الرسم." 
        : "Derive a professional 2D blueprint concept from this image with room layout, proportional logic, and drafting steps.",
    chat:
      language === "ar"
        ? "أجب كخبير معماري وإنشائي مع حلول عملية وقابلة للتنفيذ."
        : "Answer as an architecture and structural expert with practical, implementable solutions.",
  };

  if (!customPrompt?.trim()) return baseByFeature[feature];
  return `${baseByFeature[feature]}\n\nUser context:\n${customPrompt.trim()}`;
}
