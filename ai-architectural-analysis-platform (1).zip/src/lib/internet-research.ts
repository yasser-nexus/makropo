type Lang = "ar" | "en";

export type WebInsight = {
  title: string;
  snippet: string;
  source: string;
  url?: string;
};

async function fetchWithTimeout(url: string, timeoutMs = 9000): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      method: "GET",
      headers: {
        "User-Agent": "ArchAI-Core/1.0",
      },
      signal: controller.signal,
      cache: "no-store",
    });
  } finally {
    clearTimeout(timer);
  }
}

async function searchDuckDuckGo(query: string): Promise<WebInsight[]> {
  const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`;
  const res = await fetchWithTimeout(url);
  if (!res.ok) return [];

  const data = (await res.json()) as {
    AbstractText?: string;
    AbstractURL?: string;
    Heading?: string;
    RelatedTopics?: Array<{ Text?: string; FirstURL?: string } | { Topics?: Array<{ Text?: string; FirstURL?: string }> }>;
  };

  const insights: WebInsight[] = [];

  if (data.AbstractText) {
    insights.push({
      title: data.Heading || "DuckDuckGo Abstract",
      snippet: data.AbstractText,
      source: "DuckDuckGo",
      url: data.AbstractURL,
    });
  }

  for (const topic of data.RelatedTopics ?? []) {
    if ("Text" in topic && topic.Text) {
      insights.push({
        title: "Related Topic",
        snippet: topic.Text,
        source: "DuckDuckGo",
        url: topic.FirstURL,
      });
      continue;
    }

    if ("Topics" in topic && Array.isArray(topic.Topics)) {
      for (const nested of topic.Topics) {
        if (!nested.Text) continue;
        insights.push({
          title: "Related Topic",
          snippet: nested.Text,
          source: "DuckDuckGo",
          url: nested.FirstURL,
        });
      }
    }
  }

  return insights.slice(0, 6);
}

async function fetchWikipediaSummary(query: string, lang: Lang): Promise<WebInsight[]> {
  const apiLang = lang === "ar" ? "ar" : "en";
  const searchUrl = `https://${apiLang}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&utf8=1&format=json&origin=*`;
  const searchRes = await fetchWithTimeout(searchUrl);
  if (!searchRes.ok) return [];

  const searchData = (await searchRes.json()) as {
    query?: {
      search?: Array<{ title: string; snippet: string }>;
    };
  };

  const first = searchData.query?.search?.[0];
  if (!first?.title) return [];

  const summaryUrl = `https://${apiLang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(first.title)}`;
  const summaryRes = await fetchWithTimeout(summaryUrl);
  if (!summaryRes.ok) return [];

  const summary = (await summaryRes.json()) as {
    title?: string;
    extract?: string;
    content_urls?: {
      desktop?: { page?: string };
    };
  };

  if (!summary.extract) return [];

  return [
    {
      title: summary.title || first.title,
      snippet: summary.extract,
      source: "Wikipedia",
      url: summary.content_urls?.desktop?.page,
    },
  ];
}

function buildQuery(feature: string, text: string, language: Lang): string {
  const base = language === "ar" ? "معايير التصميم المعماري" : "architectural design standards";
  const topic =
    feature === "floor-plan"
      ? language === "ar"
        ? "تقييم مخطط سكني حركة وتهوية"
        : "residential floor plan circulation ventilation"
      : feature === "facade"
        ? language === "ar"
          ? "تحليل واجهة مبنى مواد ونسب"
          : "building facade proportions materiality analysis"
        : feature === "reverse-engineer"
          ? language === "ar"
            ? "تحويل صورة مبنى إلى مخطط"
            : "image to architectural blueprint workflow"
          : language === "ar"
            ? "كود البناء مواد وتشطيبات"
            : "building code material and construction guidance";

  const user = text.trim().slice(0, 120);
  return `${base} ${topic} ${user}`.trim();
}

export async function gatherInternetInsights(params: {
  feature: string;
  language: Lang;
  prompt?: string;
  chatMessage?: string;
}): Promise<WebInsight[]> {
  const query = buildQuery(params.feature, params.chatMessage || params.prompt || "", params.language);

  const [duck, wiki] = await Promise.allSettled([
    searchDuckDuckGo(query),
    fetchWikipediaSummary(query, params.language),
  ]);

  const merged: WebInsight[] = [];

  if (duck.status === "fulfilled") merged.push(...duck.value);
  if (wiki.status === "fulfilled") merged.push(...wiki.value);

  const dedup = new Map<string, WebInsight>();
  for (const item of merged) {
    const key = `${item.title}-${item.source}`.toLowerCase();
    if (!dedup.has(key)) dedup.set(key, item);
  }

  return Array.from(dedup.values()).slice(0, 8);
}

export function formatInsightsForPrompt(insights: WebInsight[], language: Lang): string {
  if (insights.length === 0) {
    return language === "ar" ? "لا توجد نتائج ويب إضافية متاحة حالياً." : "No additional web insights available right now.";
  }

  const header = language === "ar" ? "مرجع إنترنت مباشر:" : "Live internet references:";
  const lines = insights.map((ins, idx) => {
    const prefix = language === "ar" ? `مرجع ${idx + 1}` : `Ref ${idx + 1}`;
    return `${prefix}: ${ins.title} — ${ins.snippet}${ins.url ? ` (${ins.url})` : ""}`;
  });

  return [header, ...lines].join("\n");
}
