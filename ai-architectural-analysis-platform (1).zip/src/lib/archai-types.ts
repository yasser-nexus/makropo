export type FeatureKey = "floor-plan" | "facade" | "reverse-engineer" | "chat";

export type StructuredSection = {
  title: string;
  bullets: string[];
};

export type AnalysisReport = {
  title: string;
  language: "ar" | "en";
  summary: string;
  sections: StructuredSection[];
  markdown: string;
  model: string;
  provider: "python-service" | "openai" | "openrouter" | "gemini" | "local-heuristic" | "fallback";
};
