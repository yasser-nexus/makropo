import { db } from "@/db";
import { systemEvents } from "@/db/schema";
import { and, desc, eq, gt } from "drizzle-orm";

export type EventLevel = "info" | "warn" | "error";

export async function logEvent(input: {
  browserId: string;
  feature: string;
  level?: EventLevel;
  message: string;
  metadata?: Record<string, unknown>;
}) {
  try {
    const rows = await db
      .insert(systemEvents)
      .values({
        browserId: input.browserId,
        feature: input.feature,
        level: input.level ?? "info",
        message: input.message,
        metadata: input.metadata,
      })
      .returning({
        id: systemEvents.id,
        feature: systemEvents.feature,
        level: systemEvents.level,
        message: systemEvents.message,
        createdAt: systemEvents.createdAt,
      });

    return rows[0] ?? null;
  } catch {
    return null;
  }
}

export async function listEvents(input: { browserId: string; sinceId?: number; limit?: number }) {
  const limit = Math.min(Math.max(input.limit ?? 50, 1), 200);

  try {
    if (input.sinceId && input.sinceId > 0) {
      return await db
        .select({
          id: systemEvents.id,
          feature: systemEvents.feature,
          level: systemEvents.level,
          message: systemEvents.message,
          metadata: systemEvents.metadata,
          createdAt: systemEvents.createdAt,
        })
        .from(systemEvents)
        .where(and(eq(systemEvents.browserId, input.browserId), gt(systemEvents.id, input.sinceId)))
        .orderBy(desc(systemEvents.id))
        .limit(limit);
    }

    return await db
      .select({
        id: systemEvents.id,
        feature: systemEvents.feature,
        level: systemEvents.level,
        message: systemEvents.message,
        metadata: systemEvents.metadata,
        createdAt: systemEvents.createdAt,
      })
      .from(systemEvents)
      .where(eq(systemEvents.browserId, input.browserId))
      .orderBy(desc(systemEvents.id))
      .limit(limit);
  } catch {
    return [];
  }
}
