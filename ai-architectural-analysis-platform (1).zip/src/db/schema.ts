import { jsonb, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";

export const analysisJobs = pgTable("analysis_jobs", {
  id: serial("id").primaryKey(),
  browserId: varchar("browser_id", { length: 128 }).notNull().default("anonymous-browser"),
  feature: varchar("feature", { length: 64 }).notNull(),
  language: varchar("language", { length: 10 }).notNull().default("en"),
  inputName: text("input_name"),
  mimeType: text("mime_type"),
  prompt: text("prompt"),
  status: varchar("status", { length: 20 }).notNull().default("completed"),
  result: jsonb("result").$type<Record<string, unknown>>(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const systemEvents = pgTable("system_events", {
  id: serial("id").primaryKey(),
  browserId: varchar("browser_id", { length: 128 }).notNull().default("anonymous-browser"),
  feature: varchar("feature", { length: 64 }).notNull(),
  level: varchar("level", { length: 20 }).notNull().default("info"),
  message: text("message").notNull(),
  metadata: jsonb("metadata").$type<Record<string, unknown>>(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type AnalysisJob = typeof analysisJobs.$inferSelect;
export type NewAnalysisJob = typeof analysisJobs.$inferInsert;
export type SystemEvent = typeof systemEvents.$inferSelect;
