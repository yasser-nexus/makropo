# ArchAI-Core Deployment Guide

## Production readiness checklist

- [ ] Set real domain in `NEXT_PUBLIC_APP_URL`
- [ ] Configure at least one global AI provider key:
  - `OPENAI_API_KEY` or
  - `OPENROUTER_API_KEY` or
  - `GOOGLE_API_KEY` / `GEMINI_API_KEY`
- [ ] Browser-scoped projects are enabled automatically via secure cookie `archai_browser_id`
- [ ] Set strong Postgres credentials
- [ ] Run schema push on production DB
- [ ] Enable TLS/HTTPS on ingress

## Option A: Docker Compose (single VM)

1) Copy env file:

```bash
cp .env.example .env
```

2) Edit `.env` and fill real values.

3) Build and run:

```bash
docker compose -f docker-compose.prod.yml up -d --build
```

4) Apply schema:

```bash
docker compose -f docker-compose.prod.yml exec archai-web npx drizzle-kit push
```

5) Verify:

```bash
curl http://localhost:3000/api/health
```

---

## Option B: Split cloud deployment (recommended)

### 1) Database
- Use managed PostgreSQL (Neon, Supabase, RDS, Railway Postgres).
- Set `DATABASE_URL` in web service.

### 2) Backend (FastAPI)
- Deploy `backend/` using its `backend/Dockerfile`.
- Expose `8001` service.
- Set `OPENAI_API_KEY` and `OPENAI_MODEL`.

### 3) Web (Next.js)
- Deploy repo root with `Dockerfile`.
- Set env vars:
  - `DATABASE_URL`
  - `ARCHAI_PYTHON_API_URL=https://your-backend-domain`
  - optional AI keys (`OPENAI_API_KEY`, `OPENROUTER_API_KEY`, `GOOGLE_API_KEY`)

### 4) Push schema
Run once against production DB:

```bash
npx drizzle-kit push
```

---

## Runtime health endpoints

- Web health: `/api/health`
- Backend health: `/health`

---

## Zero-downtime update strategy

1) Build new image tag.
2) Run DB schema update (`drizzle-kit push`).
3) Roll out web service.
4) Roll out backend service.
5) Confirm health checks.
