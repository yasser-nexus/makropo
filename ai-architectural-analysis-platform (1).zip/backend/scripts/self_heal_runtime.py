#!/usr/bin/env python3
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOG_FILE = ROOT / "runtime_errors.log"


def analyze_logs(text: str) -> dict[str, list[str]]:
    fixes: dict[str, list[str]] = {
        "actions": [],
        "detected": [],
    }

    lower = text.lower()

    if "openai_api_key" in lower or "401" in lower:
        fixes["detected"].append("API key/authentication issue")
        fixes["actions"].append("Set OPENAI_API_KEY in backend/.env and restart service.")

    if "timeout" in lower:
        fixes["detected"].append("Provider timeout")
        fixes["actions"].append("Increase request_timeout_seconds and keep retry enabled.")

    if "json" in lower and "decode" in lower:
        fixes["detected"].append("Malformed JSON output")
        fixes["actions"].append("Keep parse_json_with_repair active and reduce model temperature.")

    if "pdf" in lower and "render" in lower:
        fixes["detected"].append("PDF rasterization failure")
        fixes["actions"].append("Validate PDF input and fallback to image upload for unstable files.")

    if not fixes["detected"]:
        fixes["detected"].append("No critical signatures detected")
        fixes["actions"].append("System appears stable. Keep periodic health checks active.")

    return fixes


def main() -> None:
    if not LOG_FILE.exists():
        print(
            json.dumps(
                {
                    "ok": True,
                    "message": "No runtime_errors.log found. Nothing to patch.",
                    "hint": "Pipe service stderr to backend/runtime_errors.log for diagnostics.",
                },
                indent=2,
            )
        )
        return

    content = LOG_FILE.read_text(encoding="utf-8", errors="ignore")
    report = analyze_logs(content)

    output = {
        "ok": True,
        "root": str(ROOT),
        "logFile": str(LOG_FILE),
        "detected": report["detected"],
        "autoPatchPlan": report["actions"],
        "environment": {
            "OPENAI_API_KEY_set": bool(os.getenv("OPENAI_API_KEY")),
            "OPENAI_MODEL": os.getenv("OPENAI_MODEL", "gpt-4o"),
        },
    }

    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
