# ArchAI-Core FastAPI Service

Production-ready multimodal AI backend for architectural analysis.

## Features
- Async FastAPI endpoints for analysis and expert chat
- Agentic multi-stage reasoning (Planner → Critic → Synthesis)
- PDF-to-image rendering for vision pipeline
- Runtime self-healing behavior:
  - retry/backoff for transient provider errors
  - JSON auto-repair for malformed model output
  - normalized exception responses with auto-patch hints

## Directory

```text
backend/
  app/
    __init__.py
    config.py
    main.py
    models.py
    services/
      __init__.py
      agentic_chain.py
      llm.py
      self_heal.py
      vision_utils.py
  scripts/
    self_heal_runtime.py
  requirements.txt
  README.md
```

## 1) Setup

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## 2) Environment

Create `backend/.env`:

```env
OPENAI_API_KEY=your_real_key
OPENAI_MODEL=gpt-4o
ENVIRONMENT=production
```

## 3) Run

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8001
```

## 4) Connect to Next.js app

Set this in project root `.env`:

```env
ARCHAI_PYTHON_API_URL=http://127.0.0.1:8001
```

## 5) Self-healing diagnostics

If you persist runtime errors in `backend/runtime_errors.log`, run:

```bash
python scripts/self_heal_runtime.py
```

The script returns a JSON auto-patch plan for common faults.

## Endpoints
- `GET /health`
- `POST /v1/analyze/floor-plan`
- `POST /v1/analyze/facade`
- `POST /v1/analyze/reverse-engineer`
- `POST /v1/chat`
