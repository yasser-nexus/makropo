from typing import Any

from app.services.llm import request_llm_json


def _feature_instruction(feature: str) -> str:
    mapping = {
        "floor-plan": "Analyze circulation, zoning, ventilation, natural light, ergonomics, and code-aware functionality.",
        "facade": "Evaluate proportions, massing, materiality, style coherence, and environmental integration.",
        "reverse-engineer": "Infer footprint, room zoning, dimensional logic, and drafting strategy from image perspective.",
        "chat": "Provide practical architecture and structural guidance with alternatives and constraints.",
    }
    return mapping.get(feature, mapping["chat"])


async def run_agentic_reasoning(
    *,
    language: str,
    feature: str,
    model: str,
    api_key: str,
    user_prompt: str,
    image_content: list[dict[str, Any]] | None,
) -> dict[str, Any]:
    lang_line = (
        "Write all output in formal Arabic."
        if language == "ar"
        else "Write all output in English."
    )

    system = "\n\n".join(
        [
            "You are ArchAI-Core, a strict chief architect and structural advisor.",
            lang_line,
            _feature_instruction(feature),
            "Always output strict JSON with keys: title, summary, sections, markdown.",
        ]
    )

    planner_user: list[dict[str, Any]] = [
        {"type": "text", "text": f"User request: {user_prompt}"},
        {
            "type": "text",
            "text": "Build an analysis plan with assumptions, evaluation criteria, and technical reasoning sequence.",
        },
    ]
    if image_content:
        planner_user.extend(image_content)

    planner = await request_llm_json(
        api_key=api_key,
        model=model,
        system_prompt=f"{system}\n\nStage: Planner",
        user_content=planner_user,
    )

    critic = await request_llm_json(
        api_key=api_key,
        model=model,
        system_prompt=f"{system}\n\nStage: Critic",
        user_content=[
            {
                "type": "text",
                "text": f"Critique this plan for missed constraints, weak assumptions, or code risks:\n{planner}",
            }
        ],
    )

    synthesis = await request_llm_json(
        api_key=api_key,
        model=model,
        system_prompt=f"{system}\n\nStage: Synthesis",
        user_content=[
            {
                "type": "text",
                "text": (
                    "Generate the final professional report using JSON schema. "
                    f"User prompt: {user_prompt}\nPlan: {planner}\nCritique: {critic}"
                ),
            }
        ],
    )

    return synthesis
