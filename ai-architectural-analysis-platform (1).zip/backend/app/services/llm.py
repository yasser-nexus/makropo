import base64
import json
from typing import Any

import httpx

from app.services.self_heal import async_retry, parse_json_with_repair

OPENAI_CHAT_COMPLETIONS_URL = "https://api.openai.com/v1/chat/completions"


@async_retry(attempts=3, base_delay=0.6, exceptions=(httpx.HTTPError, RuntimeError))
async def request_llm_json(
    *,
    api_key: str,
    model: str,
    system_prompt: str,
    user_content: list[dict[str, Any]] | str,
    temperature: float = 0.2,
) -> dict[str, Any]:
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content},
    ]

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    payload = {
        "model": model,
        "temperature": temperature,
        "response_format": {"type": "json_object"},
        "messages": messages,
    }

    async with httpx.AsyncClient(timeout=120) as client:
        response = await client.post(OPENAI_CHAT_COMPLETIONS_URL, headers=headers, json=payload)
        response.raise_for_status()
        data = response.json()

    msg = data.get("choices", [{}])[0].get("message", {}).get("content")
    if not msg:
        raise RuntimeError("Empty model response")

    if isinstance(msg, str):
        return parse_json_with_repair(msg)

    return parse_json_with_repair(json.dumps(msg))


def build_image_content(image_bytes: bytes | None, mime_type: str | None) -> list[dict[str, Any]]:
    if not image_bytes or not mime_type or not mime_type.startswith("image/"):
        return []

    b64 = base64.b64encode(image_bytes).decode("utf-8")
    return [{"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{b64}"}}]
