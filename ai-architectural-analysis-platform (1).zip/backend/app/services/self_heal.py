import asyncio
import json
from collections.abc import Awaitable, Callable
from functools import wraps
from typing import Any, TypeVar

T = TypeVar("T")


def normalize_runtime_error(exc: Exception) -> dict[str, Any]:
    message = str(exc).strip() or exc.__class__.__name__

    known_fixes: list[str] = []
    low = message.lower()

    if "timeout" in low:
        known_fixes.append("Retrying with exponential backoff can mitigate transient provider timeout.")
    if "json" in low:
        known_fixes.append("Model returned malformed JSON; apply strict parsing and sanitized extraction.")
    if "rate" in low or "429" in low:
        known_fixes.append("Throttle requests and retry with jitter after backoff.")

    if not known_fixes:
        known_fixes.append("Fallback provider will be used when available.")

    return {
        "error": message,
        "class": exc.__class__.__name__,
        "autoPatch": known_fixes,
    }


def parse_json_with_repair(raw: str) -> dict[str, Any]:
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, dict):
            return parsed
        return {"title": "Output", "summary": "Unexpected model payload", "sections": [], "markdown": raw}
    except json.JSONDecodeError:
        cleaned = raw.strip()
        start = cleaned.find("{")
        end = cleaned.rfind("}")

        if start >= 0 and end > start:
            candidate = cleaned[start : end + 1]
            try:
                parsed = json.loads(candidate)
                if isinstance(parsed, dict):
                    return parsed
            except json.JSONDecodeError:
                pass

        return {
            "title": "Recovered Output",
            "summary": "Model output was malformed JSON and has been auto-recovered.",
            "sections": [{"title": "Recovery", "bullets": ["Fallback markdown output generated."]}],
            "markdown": raw,
        }


def async_retry(
    attempts: int = 3,
    base_delay: float = 0.5,
    exceptions: tuple[type[Exception], ...] = (Exception,),
) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[T]]]:
    def decorator(fn: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        @wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> T:
            last_exc: Exception | None = None
            for i in range(attempts):
                try:
                    return await fn(*args, **kwargs)
                except exceptions as exc:  # noqa: PERF203
                    last_exc = exc
                    if i >= attempts - 1:
                        break
                    await asyncio.sleep(base_delay * (2**i))
            if last_exc:
                raise last_exc
            raise RuntimeError("Retry failed without captured exception")

        return wrapper

    return decorator
