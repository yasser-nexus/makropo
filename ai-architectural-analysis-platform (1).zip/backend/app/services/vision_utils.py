from io import BytesIO

import fitz
from PIL import Image


def pdf_first_page_to_png(pdf_bytes: bytes) -> tuple[bytes, str]:
    try:
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
        if len(doc) == 0:
            raise ValueError("Empty PDF: no pages found")

        page = doc[0]
        pix = page.get_pixmap(dpi=220)
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        output = BytesIO()
        img.save(output, format="PNG")
        return output.getvalue(), "image/png"
    except Exception as exc:
        raise RuntimeError(f"Failed to render PDF page: {exc}") from exc
