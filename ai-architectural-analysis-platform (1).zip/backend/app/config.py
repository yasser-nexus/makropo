from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "ArchAI-Core FastAPI"
    environment: str = "production"

    openai_api_key: str | None = None
    openai_model: str = "gpt-4o"

    request_timeout_seconds: int = 120
    max_retry_attempts: int = 3

    cors_origins: list[str] = Field(default_factory=lambda: ["*"])


settings = Settings()
