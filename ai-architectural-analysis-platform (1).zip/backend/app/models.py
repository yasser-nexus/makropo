from pydantic import BaseModel, Field


class Section(BaseModel):
    title: str
    bullets: list[str] = Field(default_factory=list)


class AnalyzeResponse(BaseModel):
    title: str
    summary: str
    sections: list[Section] = Field(default_factory=list)
    markdown: str
    pipeline: list[str] = Field(default_factory=list)
    provider: str = "openai"


class ChatRequest(BaseModel):
    message: str
    prompt: str | None = None
    language: str = "en"


class AnalyzeMeta(BaseModel):
    feature: str
    language: str
    file_name: str | None = None
    mime_type: str | None = None
