from typing import Any

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings
from app.models import ChatRequest
from app.services.agentic_chain import run_agentic_reasoning
from app.services.llm import build_image_content
from app.services.self_heal import normalize_runtime_error
from app.services.vision_utils import pdf_first_page_to_png

app = FastAPI(title=settings.app_name, version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def catch_all_handler(_: Request, exc: Exception) -> JSONResponse:
    details = normalize_runtime_error(exc)
    return JSONResponse(
        status_code=500,
        content={
            "ok": False,
            "error": details["error"],
            "autoPatch": details["autoPatch"],
        },
    )


@app.get("/health")
async def health() -> dict[str, Any]:
    return {"ok": True, "service": settings.app_name, "environment": settings.environment}


@app.post("/v1/analyze/{feature}")
async def analyze_feature(
    feature: str,
    file: UploadFile = File(...),
    prompt: str = Form(default=""),
    language: str = Form(default="en"),
) -> dict[str, Any]:
    if feature not in {"floor-plan", "facade", "reverse-engineer"}:
        raise HTTPException(status_code=400, detail="Unsupported feature")

    if not settings.openai_api_key:
        return {
            "title": "Fallback",
            "summary": "OPENAI_API_KEY is not configured for FastAPI service.",
            "sections": [{"title": "Status", "bullets": ["Set OPENAI_API_KEY in backend environment."]}],
            "markdown": "FastAPI backend is online but no AI key is configured.",
            "pipeline": ["init", "fallback"],
            "provider": "fallback",
        }

    raw = await file.read()
    mime = file.content_type or "application/octet-stream"

    image_bytes = raw
    image_mime = mime
    pipeline = ["init", "input-validated"]

    if mime == "application/pdf":
        image_bytes, image_mime = pdf_first_page_to_png(raw)
        pipeline.append("pdf-rendered")

    image_content = build_image_content(image_bytes, image_mime)
    pipeline.append("vision-content-built")

    custom_prompt = prompt.strip() or "Analyze this architectural input professionally."

    result = await run_agentic_reasoning(
        language="ar" if language == "ar" else "en",
        feature=feature,
        model=settings.openai_model,
        api_key=settings.openai_api_key,
        user_prompt=custom_prompt,
        image_content=image_content,
    )

    pipeline.extend(["planner", "critic", "synthesis", "completed"])
    result["pipeline"] = pipeline
    result["provider"] = "openai"
    return result


@app.post("/v1/chat")
async def chat(req: ChatRequest) -> dict[str, Any]:
    if not req.message.strip():
        raise HTTPException(status_code=400, detail="message is required")

    if not settings.openai_api_key:
        return {
            "title": "Fallback",
            "summary": "OPENAI_API_KEY is not configured for FastAPI service.",
            "sections": [{"title": "Status", "bullets": ["Set OPENAI_API_KEY in backend environment."]}],
            "markdown": "FastAPI backend is online but no AI key is configured.",
            "pipeline": ["init", "fallback"],
            "provider": "fallback",
        }

    prompt = req.prompt.strip() if req.prompt else req.message.strip()
    result = await run_agentic_reasoning(
        language="ar" if req.language == "ar" else "en",
        feature="chat",
        model=settings.openai_model,
        api_key=settings.openai_api_key,
        user_prompt=prompt,
        image_content=None,
    )

    result["pipeline"] = ["init", "planner", "critic", "synthesis", "completed"]
    result["provider"] = "openai"
    return result
