# ArchAI-Core Master System Guide

## Full Project Tree

```text
.
├─ .env
├─ .env.local
├─ drizzle.config.json
├─ eslint.config.mjs
├─ next.config.ts
├─ next-env.d.ts
├─ package.json
├─ postcss.config.mjs
├─ tsconfig.json
├─ ARCHAI_CORE_MASTER_GUIDE.md
├─ backend/
│  ├─ README.md
│  ├─ requirements.txt
│  ├─ app/
│  │  ├─ __init__.py
│  │  ├─ config.py
│  │  ├─ main.py
│  │  ├─ models.py
│  │  └─ services/
│  │     ├─ __init__.py
│  │     ├─ agentic_chain.py
│  │     ├─ llm.py
│  │     ├─ self_heal.py
│  │     └─ vision_utils.py
│  └─ scripts/
│     └─ self_heal_runtime.py
└─ src/
   ├─ app/
   │  ├─ globals.css
   │  ├─ layout.tsx
   │  ├─ page.tsx
   │  └─ api/
   │     ├─ health/route.ts
   │     └─ archai/
   │        ├─ chat/route.ts
   │        ├─ events/route.ts
   │        ├─ facade/route.ts
   │        ├─ floor-plan/route.ts
   │        ├─ jobs/route.ts
   │        └─ reverse-engineer/route.ts
   ├─ components/
   │  └─ archai-dashboard.tsx
   ├─ db/
   │  ├─ index.ts
   │  └─ schema.ts
   └─ lib/
      ├─ archai-prompts.ts
      ├─ archai-service.ts
      ├─ archai-types.ts
      ├─ job-store.ts
      └─ telemetry.ts
```

## Runtime Flow
1. User uploads image/PDF or sends chat prompt from dashboard.
2. Next.js API route logs start event in `system_events`.
3. AI orchestration tries providers in order:
   - FastAPI multimodal service (`ARCHAI_PYTHON_API_URL`)
   - OpenAI direct API (`OPENAI_API_KEY`)
   - Built-in fallback mode
4. Agentic chain performs Planner → Critic → Synthesis.
5. Report stored in `analysis_jobs` and telemetry events stream to UI.

## Local Initialization

### A) Next.js Platform
```bash
npm install
npx drizzle-kit push
npm run build
npm run dev
```

### B) FastAPI Engine (optional but recommended)
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8001
```

### C) Env Wiring
Root `.env`:
```env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
ARCHAI_PYTHON_API_URL=http://127.0.0.1:8001
OPENAI_API_KEY=your_key
ARCHAI_OPENAI_MODEL=gpt-4o-mini
```

Backend `.env`:
```env
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-4o
ENVIRONMENT=production
```

## Production Deployment
- Deploy Next.js app on a Node-compatible host.
- Deploy FastAPI service separately (container or VM).
- Configure secure environment variables in both runtimes.
- Restrict CORS origins in backend for production domains.
- Enable HTTPS and request logging at reverse-proxy layer.
